interface Human{
	void breathe();
	void eat();
}

class Mayank implements Human{
	@Override
	public void breathe(){
		System.out.println("Mayank's breathe...");
	}
	@Override
	public void eat(){
		System.out.println("Mayank's eat...");
	}
}

class Raj implements Human{
	@Override
	public void breathe(){
		System.out.println("Raj's breathe...");
	}

	@Override
	public void eat(){
		System.out.println("Raj's eat...");
	}

	void sing(){
		System.out.println("Raj can sing...");
	}
}

class RuntimePolyDemo{

	public static void main(String[] args) {
		
	

		Human []humans = new Human[3];

		// employees[0] = new Employee(); Error
		humans[0] = new Mayank();
		humans[1] = new Raj();
		humans[2] = new Mayank();

		// humans[0].breathe(); 

		// humans[1].breathe();

		// humans[2].breathe();

		// humans[1].sing();


		for(Human value : humans){
			value.breathe();
			
			if(value instanceof Raj){
				((Raj)value).sing();			
			}
		}

		// humans[1].sing();
		// humans[13].swim();
		// humans[16].dance();
		// humans[21].sing();
		// humans[7].fight();











		// Human ref = new Mayank();

		// ref.eat();

		// ref = new Raj();

		// ref.eat();
















		// humans[0].eat();

		// humans[1].sing() // Raj can sing...


		// humans[2].breathe();




	}

}

