class Some{
	void work(int val){
		System.out.println("int");
	}

	// void work(){
		
	// }
}


class OverloadRevisit{
	public static void main(String[] args) {
		
	}
}